<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setAutoRoute(true);
$routes->setDefaultController('Home');
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultMethod('index');
$routes->set404Override();
$routes->get('/', 'Home::index');
$routes->get('/v2', 'Home::version');
$routes->get('/v2/(:num)', 'Home::version/$1');
$routes->get('/v2/(:num)/(:any)', 'Home::version/$1/$2');




$routes->get('home', 'Home::index');
$routes->get('project_1', 'page2_controller::index');
$routes->get('project_2', 'page1_controller::index');
$routes->get('login', 'Login::index');
$routes->get('register', 'Register::index');
$routes->get('logout','Logout::index');

$routes->post('login','Login::do_login');



$routes->post('register','Register::do_register');
