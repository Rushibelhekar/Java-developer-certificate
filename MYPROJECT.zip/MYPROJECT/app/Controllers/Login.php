<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;


class Login extends BaseController
{
    public function index()
    {
        session_start();
        print_r($_SESSION);
       // session_destroy();
        echo view('common/header');
        echo view('login');
        echo view('common/footer');
    }

    public function do_login()
    {
        $userm = new UserModel();
        $resulte = $userm->where('email', $this->request->getVar('email'))->first();
        if ($resulte != null) {
            if ($resulte['password'] == $this->request->getVar('password')) 
            {
               $data['f_name']=$resulte['first_name'];
                session_start();
                $_SESSION['User_Name']=$resulte['first_name'];
                echo view('common/header');
                echo view('home',$data);
              //  echo "Welcome " .$resulte['first_name'];
            } else {

                echo "OPSSS Somthing went wrong";

                return view('login');
            }
        } else {
            return view('login');
        }
        echo "Login";
    }
}
