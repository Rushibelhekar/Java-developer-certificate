<?php

namespace App\Controllers;
use App\Model\UserModel;

class page2_controller extends BaseController {
    public function index() {
       
        echo view('common/header'); // Load the header view
        echo view('project_2'); // Load the home view
        // Load the footer view
    }
}