<?php

namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\UserModel;

class Register extends BaseController
{
    public function index()
    {
       
        echo view('common/header');
        echo view('register');
        echo view('common/footer');
    }

    public function do_register()
    {

      $data =['first_name'=>$this->request->getVar('first_name'),
      'last_name'=>$this->request->getVar('last_name'),
      'email'=>$this->request->getVar('email'),
      'dob'=>$this->request->getVar('dob'),
      'password'=>$this->request->getVar('password')];

      $db=  \Config\Database::connect();
      $builder=$db->table('user');

      $builder->insert($data);
      if($db)
      {
            echo "User Registerd Successfulyy !";
            echo view('common/header');
            echo view('login');
      }
      else{
            echo "Error During Registration";
      }


      
        
  
    }
   
}