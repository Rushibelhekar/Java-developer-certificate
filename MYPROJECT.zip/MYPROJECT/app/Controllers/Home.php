<?php

namespace App\Controllers;
use App\Model\UserModel;

class Home extends BaseController {
    public function index() {
     
        echo view('common/header'); // Load the header view
        echo view('home'); // Load the home view
         // Load the footer view
    }
}