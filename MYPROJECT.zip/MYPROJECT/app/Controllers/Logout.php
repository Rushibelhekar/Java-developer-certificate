<?php

namespace App\Controllers;
use App\Model\UserModel;
class Logout extends BaseController
{
    public function index()
    {
        session_start();
        $_SESSION['User_Name']='';
return redirect()->to(site_url("login"));
      }
}