<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="<<?= base_url("public/js/bootstrap.bundle.min.js"); ?>"> </script>
<nav class="navbar navbar-expand-lg bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <?php

        session_start();
        if ($_SESSION['User_Name'] != Null && $_SESSION['User_Name'] != '') {
        ?>
        
        <li class="nav-item">
            <a class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= site_url("logout"); ?>">Logout</a>
          </li>
         
        
        <?php
        } else {
        ?>
          <li class="nav-item">
            <a class="nav-link" href="<?= site_url("login"); ?>">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= site_url('register'); ?>">Register</a>
          </li>

        <?php

        }

        ?>
      </ul>
    </div>


  </div>
</nav>