<?php
namespace App\Controllers;

namespace App\Models;
use CodeIgniter\Model;

class UserModel extends Model{

      protected $table='user';
      


  

      protected $allowedFields=['first_name','last_name','email','dob','password'];


}